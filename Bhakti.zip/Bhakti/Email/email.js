function ValidateEmail(){
    var email = document.getElementById("email").value ;
    var lblError = document.getElementById("lblError");
    lblError.innerHTML = "";
    if (!ValidateEmailAddress(email) ) {
        lblError.innerHTML = "Invalid email address.";
    }
   
   
} 

function ValidateEmailAddress(email) {

    //check that email length greater than zero
    if (email.length > 0){
        return false ;
    } 

    // check Only @ should be there
    var atSymbol = email.indexOf("@");
    if(atSymbol < 1) {
        return false ;
    } 

    // check Only single . should be there after @
    var dot = email.indexOf(".");
    if(dot <= atSymbol + 2) {
        return false ;
    } 

    // Minimum 1 char should be there between @ & .
    var atSymbol = email.indexOf("@");
    var dot = email.indexOf(".");
    if(atSymbol<= (char.length = 1)<=dot) {
        return false ;
    } 
    
    // check that the dot is not at the end
    if (dot === email.length - 1){
        return false ;
    } 

    // After last dot (.) minimum 2 & max 3
    if((email.length = 2 || 3 )<= dot ) {
        return false ;
    } 

    // Space not allowed
    var nospace = email.indexOf("trim()");
    if(nospace.trim()){
        return false ;
    } 

    // After dot (.) only letters allowed
    var letter = email.indexOf("char");
    if(letter <= dot +2) {
        return false ;
    } 
    else {
            return true;
    }
}

