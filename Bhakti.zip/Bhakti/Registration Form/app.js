const userInfo =JSON.parse(localStorage.getItem("userInfo")) ||[];

function mainFunc(){
    if (FirstNameValidate()) {
        if (LastNameValidate()) {
            if (ContactNoValidate()) {
                if (emailValidate()) {
                    if (AddressValidate()) {
                        if (ProfilepicValidate()) {
                            if (passwordValidate()) {
                                alert ("form submited")
                                 const obj = {
                                    firstname: FirstName.value,
                                    lastname: LastName.value,
                                    contactno: ContactNo.value,
                                    email: email.value,
                                    address: Address.value,
                                    profilepic: Profilepic.value,
                                    password: password.value
                                }
                                userInfo.push(obj);
                                localStorage.setItem("userInfo",JSON.stringify(userInfo));
                            }
                        }
                    }
                }
            }
        }
    }
    else {
       alert ("please fill this details")
    }
}

function userDetails(){
        const output = document.getElementById("output");
        const FirstName= document.getElementById("FirstName").value;
        const LastName= document.getElementById("LastName").value;
        const ContactNo= document.getElementById("ContactNo").value;
        const email= document.getElementById("email").value;
        const Address= document.getElementById("Address").value;
        const Profilepic= document.getElementById("Profilepic").value;
        const password= document.getElementById("password").value;

        output.innerHTML = `<h1>I am a user</h1>`;
}

function FirstNameValidate(){
    const FirstName= document.getElementById("FirstName").value;
    const regularExpression  = /^([a-zA-Z]{2,20})$/;
    if (FirstName.match(regularExpression)){
        return true
    }     
    alert("Invalid First Name")
    FirstName.focus();
    return false   
}
function LastNameValidate(){
    const LastName= document.getElementById("LastName").value;
    const regularExpression  = /^([a-zA-Z]{2,20})$/;
    if (LastName.match(regularExpression)){
        return true
    }     
    alert("Invalid Last Name")
    LastName.focus();
    return false   
}
function ContactNoValidate(){
    const ContactNo= document.getElementById("ContactNo").value;
    const regularExpression  = /^([0-9]{10})$/;
    if (ContactNo.match(regularExpression)){
        return true
    }     
    alert("Invalid ContactNo")
    ContactNo.focus();
    return false   
}
function emailValidate(){
    const email= document.getElementById("email").value;
    const regularExpression  = /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
    if (email.match(regularExpression)){
      return true
    }     
    alert("Invalid Email")
    email.focus();
    return false   
}
function AddressValidate(){
    const Address= document.getElementById("Address").value;
    const regularExpression  = /^[a-zA-Z0-9\s,'-]*$/;
    if (Address.match(regularExpression)){
        return true
    }     
    alert("Invalid Address")
    Address.focus();
    return false   
}
function ProfilepicValidate(){
    const Profilepic= document.getElementById("Profilepic").value;
    const regularExpression  = /[0-9a-z]+$/;
    if (Profilepic.match(regularExpression)){
        return true
    }     
    alert("Invalid Profile Picture")
    Profilepic.focus();
    return false   
}
function passwordValidate(){
    const password= document.getElementById("password").value;
    
    const regularExpression  = /^[a-zA-Z0-9!@#$%^&*]{6,16}$/;
    if (password.match(regularExpression)){
        return true
    }                
    alert("Invalid Password");
    password.focus();
    return false   
}